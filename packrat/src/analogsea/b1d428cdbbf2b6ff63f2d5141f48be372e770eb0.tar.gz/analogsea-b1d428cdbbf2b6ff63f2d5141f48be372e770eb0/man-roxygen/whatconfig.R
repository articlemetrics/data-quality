#' @param what (character) One of 'parsed' or 'raw'.
#' @param config Options passed on to httr::GET. Must be named, see examples.
