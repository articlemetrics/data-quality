#' @param id (numeric) A droplet id (optional)
