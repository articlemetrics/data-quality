#' @param page Page number (Default: 1)
#' @param per_page Number of items per page (Default: 25)
