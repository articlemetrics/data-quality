R CMD CHECK passed on my local OS X install with R 3.1.1 and R development version, Ubuntu running on Travis-CI, and Win builder.

This submission changes the package title in the DESCRIPTION file to title case, and expands on description of rCharts use in the package. 

Thanks! Scott Chamberlain
