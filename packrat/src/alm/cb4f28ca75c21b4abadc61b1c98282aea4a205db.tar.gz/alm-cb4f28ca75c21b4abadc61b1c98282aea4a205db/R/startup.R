.onAttach <- function(...) {
	packageStartupMessage("\n\n New to alm? Tutorial at http://ropensci.org/tutorials/alm_tutorial.html. Use suppressPackageStartupMessages() to suppress these startup messages in the future\n")
} 