FigshareAuthCache <- new.env(hash=TRUE)
