library("testthat")
test_check("rcrossref")
