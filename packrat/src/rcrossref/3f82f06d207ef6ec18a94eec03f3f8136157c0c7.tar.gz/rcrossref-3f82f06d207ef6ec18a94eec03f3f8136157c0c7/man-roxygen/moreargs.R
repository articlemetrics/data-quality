#' @param .progress Show a \code{plyr}-style progress bar? Options are "none", "text", "tk", "win, 
#' and "time".  See \link[plyr]{create_progress_bar} for details of each.
#' @param ... Named parameters passed on to httr::GET
